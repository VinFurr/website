
<html>
  <head>
    <title></title>
    <style>
      table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
      }
      td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
      }
      tr:nth-child(even) {
        background-color: #dddddd;
      }
    </style>
  </head>
  <body>
    <!--
 ____              __                                                          __
/\  _`\           /\ \                                                        /\ \
\ \ \L\_\   ___   \_\ \        ____   ___    ___ ___     ___ ___      __  _ __\ \ \
 \ \ \L_L  / __`\ /'_` \      /',__\ / __`\/' __` __`\ /' __` __`\  /'__`\\`'__\ \ \
  \ \ \/, \\ \L\ \\ \L\ \    /\__, `\\ \L\ \\ \/\ \/\ \/\ \/\ \/\ \/\  __/ \ \/ \ \_\
   \ \____/ \____/ \___,_\   \/\____/ \____/ \_\ \_\ \_\ \_\ \_\ \_\ \____\ \_\  \/\_\
    \/___/ \/___/ \/__,_ /    \/___/ \/___/ \/_/\/_/\/_/\/_/\/_/\/_/\/____/\/_/   \/_/

                                Hilsen Vincent!
-->
    <center>
      <table>
        <tr>
          <td>Del1</td>
          <td><br>
            <a href="./del1 kundeliste opprett hvis ikke eksistere.php">kundeliste opprett</a><br>
            <a href="./del1 bordplass opprett hvis ikke eksistere.php">bordplass opprett</a><br>
          </td>
        </tr>
        <tr>
          <td>Del2</td>
          <td><br>
            <a href="./del2 bordplassregistrering.php">bordregistrering</a><br>
            <a href="./del2 kunderegistrering ankomst og avreise.php">kunderegistrering</a><br>
          </td>
        </tr>
        <tr>
          <td>Del3</td>
          <td><br>
            <a href="./del3 liste over alle bordplasser.php">liste alle bordplasser</a><br>
            <a href="./del3 liste over alle ledige plasser.php">liste ledige bordplasser</a><br>
            <a href="./del3 liste over alle opptatte plasser.php">liste alle opptatte plasser</a><br>
            <a href="./del3 liste over alle registrerte kunder.php">liste alle registrerte kunder</a><br>
          </td>
        </tr>
        <tr>
          <td>Del4</td>
          <td><br>
            <a href="./del4 kunde sjekk inn.php">kunde sjekk inn</a><br>
            <a href="./del4 kunde sjekk ut.php">kunde sjekk ut</a><br>
          </td>
        </tr>
      </table>
    </center>
  </body>
</html>
